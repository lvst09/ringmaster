//
//  YoutuBeautyManager.h
//  youtubeauty
//
//  Created by peicheng on 14/12/12.
//  Copyright (c) 2014年 tencent. All rights reserved.
//


@interface YoutuBeautyManager : NSObject

+ (instancetype) sharedManager;
- (void) setupEnviroment;

@end

